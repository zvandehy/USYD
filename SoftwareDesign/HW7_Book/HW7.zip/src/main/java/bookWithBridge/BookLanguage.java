package bookWithBridge;

public interface BookLanguage {
    public String getBookLanguage();
}
