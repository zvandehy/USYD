package bookWithBridge;

public class NonFiction implements BookGenre {

    @Override
    public String getBookGenre() {
        return "Non-Fiction";
    }
}
