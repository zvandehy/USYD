package bookWithBridge;

public interface BookType {
    public String getBookType();
}
