package bookWithBridge;

public class Fiction implements BookGenre {

    @Override
    public String getBookGenre() {
        return "Fiction";
    }
}
