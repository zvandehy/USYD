package bookWithBridge;

public interface BookGenre {
    public String getBookGenre();
}
