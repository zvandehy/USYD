package bookWithBridge;

public class HardCover implements BookType {
    @Override
    public String getBookType() {
        return "a HardCover";
    }
}
