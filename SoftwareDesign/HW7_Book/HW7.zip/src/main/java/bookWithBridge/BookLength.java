package bookWithBridge;

public interface BookLength {
    public String getBookLength();
}
