package bookWithBridge;

public class English implements BookLanguage {
    @Override
    public String getBookLanguage() {
        return "English";
    }
}
