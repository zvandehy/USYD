package bookWithBridge;

public class SoftCover implements BookType {
    @Override
    public String getBookType() {
        return "a SoftCover";
    }
}
