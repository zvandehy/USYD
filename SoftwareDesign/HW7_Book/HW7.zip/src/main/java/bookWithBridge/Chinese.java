package bookWithBridge;

public class Chinese implements BookLanguage {
    @Override
    public String getBookLanguage() {
        return "Chinese";
    }
}
