package bookWithBridge;

public class Spanish implements BookLanguage {
    @Override
    public String getBookLanguage() {
        return "Spanish";
    }
}
