package bookWithBridge;

public class MediumBook implements BookLength{

    @Override
    public String getBookLength() {
        return "Medium Book";
    }
}
