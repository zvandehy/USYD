package bookWithInheritance;

public abstract class HardcoverBook implements Book{
    public void read() {
        System.out.println("Reading a HardCover book");
    }
}
