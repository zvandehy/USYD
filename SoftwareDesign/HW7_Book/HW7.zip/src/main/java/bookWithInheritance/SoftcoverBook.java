package bookWithInheritance;

public abstract class SoftcoverBook implements Book{
    public void read() {
        System.out.println("Reading a SoftCover book");
    }
}
