package bookWithInheritance;

public abstract class EBook implements Book{
    public void read() {
        System.out.println("Reading an Ebook");
    }
}
