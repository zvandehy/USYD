package bookWithInheritance;

public interface Book {
    public void read();
}
